export interface User {
    empId: string;
    email: string;
    password: string;
  }
  